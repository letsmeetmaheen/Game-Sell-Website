import { unstable_cache } from 'next/cache'
import { getPayloadClient, findBySlug } from './payload'
export const getGames = unstable_cache(
  async () => {
    const payload = await getPayloadClient()
    const result = await payload.find({
      collection: 'games',
      overrideAccess: false,
      limit: 50,
      depth: 1,
      sort: 'createdAt',
    })
    return result.docs
  },
  ['shop-games-catalog-v1'],
  { tags: ['games'] },
)
export const getGame = unstable_cache(
  async (slug: string) => findBySlug('games', slug),
  ['shop-game'],
  { tags: ['games'] },
)
