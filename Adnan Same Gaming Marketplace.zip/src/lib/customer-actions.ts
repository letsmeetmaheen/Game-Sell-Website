'use server'
import { appAuth } from './app-auth'
import { getPayloadClient } from './payload'

export async function customerSession() {
  const user = await appAuth.currentUser()
  if (!user) return null
  const payload = await getPayloadClient()
  const orders = await payload.find({
    collection: 'orders',
    user,
    overrideAccess: false,
    limit: 50,
    sort: '-createdAt',
    depth: 1,
  })
  return {
    name: user.name,
    email: user.email,
    orders: orders.docs.map((o) => ({
      reference: o.reference,
      status: o.status,
      date: o.createdAt,
    })),
  }
}
export async function authenticateCustomer(form: FormData) {
  const email = String(form.get('email') || '')
    .trim()
    .toLowerCase()
  const password = String(form.get('password') || '')
  const name = String(form.get('name') || '').trim()
  if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
    email.length > 254 ||
    password.length < 8 ||
    password.length > 128
  )
    return { error: 'Use a valid email and a password of 8–128 characters.' }
  try {
    if (form.get('mode') === 'register') {
      if (!name || name.length > 100) return { error: 'Enter your name (up to 100 characters).' }
      const payload = await getPayloadClient()
      await payload.create({
        collection: 'users',
        overrideAccess: false,
        data: { email, password, name },
      })
    }
    await appAuth.login(email, password)
    return { success: true }
  } catch {
    return {
      error: 'Could not sign in or create account. Check your details or try another email.',
    }
  }
}
export async function logoutCustomer() {
  await appAuth.logout()
  return { success: true }
}
export async function placeDemoOrder(form: FormData, ids: string[]) {
  const user = await appAuth.currentUser()
  if (!user) return { error: 'Please sign in before saving a demo order.' }
  const phone = String(form.get('phone') || '').trim()
  const contact = String(form.get('contact') || '').trim()
  const payment = String(form.get('payment') || '')
  if (
    !/^[+\d ()-]{7,30}$/.test(phone) ||
    contact.length > 500 ||
    !['bKash', 'Nagad', 'Rocket', 'Visa', 'Mastercard'].includes(payment) ||
    !Array.isArray(ids) ||
    ids.length < 1 ||
    ids.length > 8 ||
    ids.some((id) => typeof id !== 'string')
  )
    return { error: 'Check your phone, payment preference, and cart.' }
  try {
    const payload = await getPayloadClient()
    const order = await payload.create({
      collection: 'orders',
      user,
      overrideAccess: false,
      data: {
        customer: user.id,
        games: [...new Set(ids)],
        phone,
        contact,
        payment: payment as 'bKash',
      },
    })
    return { reference: order.reference }
  } catch {
    return { error: 'The demo order could not be saved. Please try again.' }
  }
}
