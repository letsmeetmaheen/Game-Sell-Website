import type { CollectionConfig } from 'payload'
import { revalidatePath, revalidateTag } from 'next/cache'

import { createFolderField, createTagField } from 'payload'

export const Media: CollectionConfig = {
  slug: 'media',
  access: {
    read: () => true,
  },
  fields: [
    {
      name: 'alt',
      type: 'text',
      required: true,
    },
    createFolderField({ relationTo: 'folders' }),
    createTagField({ relationTo: 'tags' }),
  ],
  hooks: {
    afterChange: [
      ({ doc }) => {
        revalidateTag('games', { expire: 0 })
        revalidatePath('/', 'layout')
        return doc
      },
    ],
    afterDelete: [
      ({ doc }) => {
        revalidateTag('games', { expire: 0 })
        revalidatePath('/', 'layout')
        return doc
      },
    ],
  },
  upload: {
    modifyResponseHeaders: ({ headers }) => {
      headers.set('Cache-Control', 'public, max-age=3600, s-maxage=3600')
      return headers
    },
  },
}
