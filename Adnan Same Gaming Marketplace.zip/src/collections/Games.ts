import type { CollectionConfig } from 'payload'
import { revalidatePath, revalidateTag } from 'next/cache'

const invalidate = (slugs: (string | undefined)[]) => {
  revalidateTag('games', { expire: 0 })
  revalidatePath('/')
  revalidatePath('/games')
  for (const slug of slugs) if (slug) revalidatePath(`/games/${slug}`)
}

export const Games: CollectionConfig = {
  slug: 'games',
  admin: { useAsTitle: 'title', group: 'Shop', defaultColumns: ['title', 'price', 'availability'] },
  access: {
    read: () => true,
    create: ({ req }) => req.user?.collection === 'admins',
    update: ({ req }) => req.user?.collection === 'admins',
    delete: ({ req }) => req.user?.collection === 'admins',
  },
  hooks: {
    afterChange: [
      ({ doc, previousDoc }) => {
        invalidate([doc.slug, previousDoc?.slug])
        return doc
      },
    ],
    afterDelete: [
      ({ doc }) => {
        invalidate([doc.slug])
        return doc
      },
    ],
  },
  fields: [
    { name: 'title', type: 'text', required: true },
    { name: 'slug', type: 'slug', useAsSlug: 'title' },
    { name: 'cover', type: 'upload', relationTo: 'media' },
    { name: 'banner', type: 'upload', relationTo: 'media' },
    { name: 'artworkNote', type: 'text' },
    { name: 'description', type: 'textarea', required: true },
    { name: 'developer', type: 'text' },
    { name: 'publisher', type: 'text' },
    { name: 'release', type: 'text' },
    {
      name: 'genre',
      type: 'select',
      options: ['Action RPG', 'Adventure', 'Sports', 'Open World', 'Action'],
    },
    { name: 'platforms', type: 'select', hasMany: true, options: ['PC', 'PlayStation', 'Xbox'] },
    { name: 'price', type: 'number', required: true, min: 0 },
    { name: 'originalPrice', type: 'number', min: 0 },
    { name: 'demoPrice', type: 'checkbox', defaultValue: true },
    {
      name: 'availability',
      type: 'select',
      defaultValue: 'demo',
      options: [
        { label: 'Demo catalog', value: 'demo' },
        { label: 'Coming soon', value: 'coming-soon' },
        { label: 'In stock', value: 'available' },
      ],
    },
    { name: 'badge', type: 'text' },
    { name: 'featured', type: 'checkbox', defaultValue: false },
    { name: 'requirements', type: 'textarea' },
    { name: 'accessConditions', type: 'textarea' },
    { name: 'trailerURL', type: 'text' },
  ],
}
