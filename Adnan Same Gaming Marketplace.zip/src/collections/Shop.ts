import type { Access, CollectionConfig } from 'payload'
const admin: Access = ({ req }) => req.user?.collection === 'admins'
const own: Access = ({ req }) =>
  req.user?.collection === 'admins'
    ? true
    : req.user?.collection === 'users'
      ? { id: { equals: req.user.id } }
      : false
const owned: Access = ({ req }) =>
  req.user?.collection === 'admins'
    ? true
    : req.user?.collection === 'users'
      ? { customer: { equals: req.user.id } }
      : false

export const Users: CollectionConfig = {
  slug: 'users',
  auth: true,
  admin: { useAsTitle: 'email', group: 'Customers' },
  access: { create: () => true, read: own, update: own, delete: admin, admin: () => false },
  fields: [
    { name: 'name', type: 'text', required: true, maxLength: 100 },
    { name: 'phone', type: 'text', maxLength: 30 },
    { name: 'wishlist', type: 'relationship', relationTo: 'games', hasMany: true },
  ],
}
export const Orders: CollectionConfig = {
  slug: 'orders',
  admin: { useAsTitle: 'reference', group: 'Shop' },
  access: {
    create: ({ req }) => req.user?.collection === 'users',
    read: owned,
    update: admin,
    delete: admin,
  },
  hooks: {
    beforeChange: [
      async ({ data, req, operation }) => {
        if (operation === 'create' && data) {
          if (req.user?.collection !== 'users') throw new Error('Customer account required')
          const ids = Array.isArray(data.games) ? data.games : []
          if (!ids.length || ids.length > 8 || ids.some((id) => typeof id !== 'string'))
            throw new Error('Invalid cart')
          const games = await req.payload.find({
            collection: 'games',
            overrideAccess: false,
            user: req.user,
            req,
            where: { id: { in: ids } },
            limit: 8,
            depth: 0,
          })
          if (games.docs.length !== new Set(ids).size) throw new Error('Game unavailable')
          data.customer = req.user.id
          data.total = 0
          data.status = 'demo'
        }
        return data
      },
    ],
    beforeValidate: [
      ({ data, req, operation }) => {
        if (operation === 'create' && req.user?.collection === 'users' && data) {
          data.customer = req.user.id
          data.reference = `ASS-${crypto.randomUUID().slice(0, 8).toUpperCase()}`
          data.status = 'demo'
          data.total = 0
        }
        return data
      },
    ],
  },
  fields: [
    {
      name: 'reference',
      type: 'text',
      access: { create: () => false, update: ({ req }) => req.user?.collection === 'admins' },
    },
    { name: 'customer', type: 'relationship', relationTo: 'users', required: true },
    {
      name: 'status',
      type: 'select',
      defaultValue: 'demo',
      options: ['demo', 'pending', 'processing', 'completed', 'cancelled'],
      access: { create: () => false, update: ({ req }) => req.user?.collection === 'admins' },
    },
    { name: 'games', type: 'relationship', relationTo: 'games', hasMany: true, required: true },
    { name: 'phone', type: 'text', required: true, maxLength: 30 },
    { name: 'contact', type: 'textarea', maxLength: 500 },
    {
      name: 'payment',
      type: 'select',
      options: ['bKash', 'Nagad', 'Rocket', 'Visa', 'Mastercard'],
      required: true,
    },
    {
      name: 'total',
      type: 'number',
      defaultValue: 0,
      access: { create: () => false, update: ({ req }) => req.user?.collection === 'admins' },
    },
  ],
}
