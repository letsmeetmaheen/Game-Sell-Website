'use client'
import { useEffect, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import {
  authenticateCustomer,
  customerSession,
  logoutCustomer,
  placeDemoOrder,
} from '@/lib/customer-actions'
type Session = Awaited<ReturnType<typeof customerSession>>
export function CustomerAccount() {
  const [session, setSession] = useState<Session>(null),
    [ready, setReady] = useState(false),
    [mode, setMode] = useState('login'),
    [error, setError] = useState(''),
    [pending, start] = useTransition()
  const router = useRouter()
  useEffect(() => {
    customerSession()
      .then((s) => {
        setSession(s)
        setReady(true)
      })
      .catch(() => {
        setReady(true)
        setError('Account service is temporarily unavailable.')
      })
  }, [])
  if (!ready) return <p className="text-sm text-zinc-400">Loading your player profile…</p>
  if (session)
    return (
      <div>
        <div className="rounded-xl border border-white/10 bg-white/5 p-5">
          <p className="text-[10px] tracking-widest text-red-400">PLAYER PROFILE</p>
          <h3 className="mt-2 text-2xl font-bold">{session.name}</h3>
          <p className="mt-2 text-xs text-zinc-400">{session.email}</p>
        </div>
        <div className="mt-5 grid grid-cols-3 gap-3">
          {[
            ['Orders', session.orders.length],
            ['Collection', 0],
            ['Payments', 0],
          ].map(([k, v]) => (
            <div className="rounded-lg bg-white/5 p-4" key={k}>
              <b className="text-xl">{v}</b>
              <p className="mt-2 text-[10px] text-zinc-500">{k}</p>
            </div>
          ))}
        </div>
        <h3 className="my-5 font-bold">My orders & tracking</h3>
        {!session.orders.length ? (
          <p className="text-xs leading-6 text-zinc-500">
            No orders yet. Save a demo checkout to see your order here. Demo orders do not add games
            to your collection and never charge you.
          </p>
        ) : (
          session.orders.map((o) => (
            <div
              key={o.reference}
              className="mb-3 flex justify-between rounded-lg border border-white/10 p-4 text-xs"
            >
              <div>
                {o.reference}
                <p className="mt-2 text-zinc-500">{new Date(o.date).toLocaleDateString()}</p>
              </div>
              <span className="text-amber-300">{o.status} · No charge</span>
            </div>
          ))
        )}
        <button
          disabled={pending}
          onClick={() =>
            start(async () => {
              await logoutCustomer()
              setSession(null)
              router.refresh()
            })
          }
          className="mt-6 rounded-lg border border-white/20 px-5 py-3 text-xs"
        >
          Sign out
        </button>
      </div>
    )
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault()
        const form = new FormData(e.currentTarget)
        start(async () => {
          const r = await authenticateCustomer(form)
          if (r.error) setError(r.error)
          else {
            setError('')
            setSession(await customerSession())
            router.refresh()
          }
        })
      }}
      className="space-y-4"
    >
      <p className="mb-6 text-sm text-zinc-400">Your games. Your orders. One place.</p>
      <input name="mode" type="hidden" value={mode} />
      {mode === 'register' && (
        <input
          aria-label="Full name"
          name="name"
          required
          maxLength={100}
          placeholder="Full name"
          className="w-full rounded-lg border border-white/10 bg-[#20212d] p-3 text-sm"
        />
      )}
      <input
        aria-label="Email"
        name="email"
        type="email"
        required
        placeholder="Email address"
        className="w-full rounded-lg border border-white/10 bg-[#20212d] p-3 text-sm"
      />
      <input
        aria-label="Password"
        name="password"
        type="password"
        minLength={8}
        maxLength={128}
        required
        autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
        placeholder="Password (8+ characters)"
        className="w-full rounded-lg border border-white/10 bg-[#20212d] p-3 text-sm"
      />
      {error && (
        <p role="alert" className="text-xs text-red-400">
          {error}
        </p>
      )}
      <button
        disabled={pending}
        className="w-full rounded-lg bg-red-500 p-3.5 text-sm font-bold disabled:opacity-50"
      >
        {pending ? 'Please wait…' : mode === 'register' ? 'Create account' : 'Sign in'}
      </button>
      <button
        type="button"
        onClick={() => {
          setMode(mode === 'login' ? 'register' : 'login')
          setError('')
        }}
        className="w-full text-xs text-zinc-400"
      >
        {mode === 'login'
          ? 'New here? Create your player account →'
          : 'Already a player? Sign in →'}
      </button>
    </form>
  )
}
export function DemoCheckout({
  ids,
  onSuccess,
}: {
  ids: string[]
  onSuccess: (reference: string) => void
}) {
  const [pending, start] = useTransition(),
    [error, E] = useState('')
  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault()
        const f = new FormData(e.currentTarget)
        start(async () => {
          const r = await placeDemoOrder(f, ids)
          if (r.error) E(r.error)
          else onSuccess(r.reference || 'Demo order')
        })
      }}
    >
      <p className="text-xs leading-6 text-amber-300">
        Demo order only. Sign in first to save it to your account. No payment is collected, no game
        is delivered, and no payment credentials are needed.
      </p>
      <input
        name="phone"
        required
        aria-label="Phone number"
        placeholder="Contact phone number"
        className="w-full rounded-lg border border-white/10 bg-[#20212d] p-3 text-sm"
      />
      <textarea
        name="contact"
        maxLength={500}
        aria-label="Delivery instructions"
        placeholder="Contact / delivery instructions (optional)"
        className="w-full rounded-lg border border-white/10 bg-[#20212d] p-3 text-sm"
      />
      <select
        name="payment"
        aria-label="Payment preference"
        className="w-full rounded-lg bg-[#20212d] p-3 text-sm"
      >
        {['bKash', 'Nagad', 'Rocket', 'Visa', 'Mastercard'].map((x) => (
          <option key={x}>{x}</option>
        ))}
      </select>
      {error && (
        <p role="alert" className="text-xs text-red-400">
          {error}
        </p>
      )}
      <button
        disabled={pending}
        className="w-full rounded-lg bg-red-500 p-4 text-sm font-bold disabled:opacity-50"
      >
        {pending ? 'Saving…' : 'Confirm demo order · No charge'}
      </button>
    </form>
  )
}
