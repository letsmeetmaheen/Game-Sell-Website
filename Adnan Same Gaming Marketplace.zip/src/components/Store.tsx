'use client'
import { useState, useEffect } from 'react'
import { CustomerAccount, DemoCheckout } from './Customer'
import Image from 'next/image'
import Link from 'next/link'
import type { Game, Media } from '@/payload-types'
const money = (n: number) => '৳' + n.toLocaleString('en-IN')
function Icon({ name, className = '' }: { name: string; className?: string }) {
  return (
    <svg
      className={className}
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {name === 'heart' ? (
        <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" />
      ) : name === 'search' ? (
        <>
          <circle cx="10.5" cy="10.5" r="7" />
          <path d="m16 16 5 5" />
        </>
      ) : name === 'cart' ? (
        <>
          <path d="M3 3h2l3 13h11l3-9H6" />
          <circle cx="9" cy="21" r="1" />
          <circle cx="19" cy="21" r="1" />
        </>
      ) : name === 'user' ? (
        <>
          <circle cx="12" cy="8" r="4" />
          <path d="M4 22v-3a8 8 0 0 1 16 0v3" />
        </>
      ) : name === 'pc' ? (
        <>
          <rect x="2" y="3" width="20" height="14" rx="2" />
          <path d="M8 21h8m-4-4v4" />
        </>
      ) : name === 'game' ? (
        <>
          <path d="M7 7h10c4 0 7 13 3 13-2 0-3-4-5-4H9c-2 0-3 4-5 4C0 20 3 7 7 7Z" />
          <path d="M6 11v4m-2-2h4m8-1h.01m3 3h.01" />
        </>
      ) : name === 'bolt' ? (
        <path d="m13 2-9 12h7l-1 8 10-13h-7l1-7Z" />
      ) : name === 'shield' ? (
        <>
          <path d="m12 2 9 4v6c0 6-9 10-9 10S3 18 3 12V6l9-4Z" />
          <path d="m8 12 3 3 5-6" />
        </>
      ) : name === 'headset' ? (
        <>
          <path d="M3 14v-3a9 9 0 0 1 18 0v7c0 3-3 4-7 4" />
          <rect x="2" y="11" width="4" height="8" rx="2" />
          <rect x="18" y="11" width="4" height="8" rx="2" />
        </>
      ) : name === 'close' ? (
        <path d="m6 6 12 12M6 18 18 6" />
      ) : name === 'menu' ? (
        <path d="M3 6h18M3 12h18M3 18h18" />
      ) : (
        <path d="M4 12h16m-6-6 6 6-6 6" />
      )}
    </svg>
  )
}
export function Art({
  game,
  banner = false,
  className = '',
}: {
  game: Game
  banner?: boolean
  className?: string
}) {
  const m = (banner ? game.banner : game.cover) as Media | null
  return m?.url ? (
    <Image
      src={m.url}
      alt={`${game.title} ${banner ? 'cinematic artwork' : 'official cover'}`}
      fill
      sizes={banner ? '100vw' : '(max-width: 640px) 50vw, 25vw'}
      className={`object-cover ${className}`}
    />
  ) : (
    <div className="flex h-full items-center justify-center bg-gradient-to-br from-red-950 to-zinc-900 p-5 text-center text-xl font-bold">
      {game.title}
      <span className="text-xs">Artwork placeholder</span>
    </div>
  )
}
export default function Store({
  games,
  detail,
  catalog = false,
}: {
  games: Game[]
  detail?: Game
  catalog?: boolean
}) {
  const [filter, F] = useState('All Games'),
    [query, Q] = useState(''),
    [sort, S] = useState('Featured'),
    [wish, W] = useState<string[]>([]),
    [cart, C] = useState<Game[]>([]),
    [panel, P] = useState(''),
    [menu, M] = useState(false),
    [notice, N] = useState(''),
    [slide, H] = useState(0)
  useEffect(() => {
    try {
      const data = JSON.parse(sessionStorage.getItem('adnan-visit') || '{}')
      if (Array.isArray(data.cart)) C(games.filter((g) => data.cart.includes(g.id)))
      if (Array.isArray(data.wish)) W(data.wish)
    } catch {}
  }, [games])
  useEffect(() => {
    if (cart.length || wish.length)
      sessionStorage.setItem('adnan-visit', JSON.stringify({ cart: cart.map((g) => g.id), wish }))
  }, [cart, wish])
  const hero = games.find((g) => g.slug === 'black-myth-wukong') || games[0]
  const heroes = [hero, ...games.filter((g) => g.featured && g.id !== hero?.id)]
  const current = heroes[slide % heroes.length]
  const toggle = (g: Game) =>
    W(wish.includes(g.id) ? wish.filter((x) => x !== g.id) : [...wish, g.id])
  const add = (g: Game) => {
    if (!cart.some((x) => x.id === g.id)) C([...cart, g])
    N(`${g.title} added to your demo cart`)
    setTimeout(() => N(''), 3000)
  }
  let shown = games.filter(
    (g) =>
      (filter === 'All Games' ||
        filter === 'Offline' ||
        filter === 'Online' ||
        (filter === 'Best Sellers'
          ? g.featured
          : filter === 'New Releases'
            ? !!g.badge
            : g.platforms?.includes(filter as 'PC'))) &&
      g.title.toLowerCase().includes(query.toLowerCase()),
  )
  if (sort === 'Price: Low to High') shown = [...shown].sort((a, b) => a.price - b.price)
  if (sort === 'Price: High to Low') shown = [...shown].sort((a, b) => b.price - a.price)
  const card = (g: Game) => (
    <article
      key={g.id}
      className="group min-w-0 overflow-hidden rounded-xl border border-white/[.07] bg-[#14151d] transition duration-300 hover:-translate-y-1 hover:border-red-500/50"
    >
      <div className="relative aspect-[.76] overflow-hidden">
        <Link href={`/games/${g.slug}`} className="absolute inset-0">
          <Art game={g} className="transition duration-700 group-hover:scale-105" />
        </Link>
        <span className="absolute left-3 top-3 rounded bg-[#ff3038] px-2 py-1 text-[10px] font-bold">
          {g.badge || `-${Math.round((1 - g.price / (g.originalPrice || g.price)) * 100)}%`}
        </span>
        <button
          aria-label={`Wishlist ${g.title}`}
          onClick={() => toggle(g)}
          className={`absolute right-3 top-3 rounded-full bg-black/50 p-2 backdrop-blur ${wish.includes(g.id) ? 'text-red-500' : 'text-white'}`}
        >
          <Icon name="heart" />
        </button>
        <span className="absolute bottom-3 left-3 rounded border border-white/20 bg-black/70 px-2 py-1 text-[9px] tracking-wider backdrop-blur">
          {g.genre?.toUpperCase()}
        </span>
      </div>
      <div className="p-3 sm:p-4">
        <div className="mb-2 flex gap-2 text-[10px] text-zinc-400">
          <Icon name="pc" className="h-3 w-3" />
          {g.platforms?.join(' · ')}
        </div>
        <Link href={`/games/${g.slug}`} className="font-heading text-sm font-bold sm:text-base">
          {g.title}
        </Link>
        <p className="mt-1 text-[10px] text-zinc-500">Standard Edition · Licensed access</p>
        <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-3">
          <div>
            <span className="mr-2 text-base font-bold text-white sm:text-lg">{money(g.price)}</span>
            <s className="text-[10px] text-zinc-500">{money(g.originalPrice || g.price)}</s>
            <p className="mt-1 text-[9px] text-zinc-500">Demo price</p>
          </div>
          <button
            onClick={() => add(g)}
            aria-label={`Add ${g.title} to cart`}
            className="rounded-lg border border-white/10 bg-white/5 p-2 transition hover:bg-red-500"
          >
            <Icon name="cart" className="h-4 w-4" />
          </button>
        </div>
      </div>
    </article>
  )
  return (
    <div className="min-h-screen bg-[#08090d] pb-16 text-white md:pb-0">
      <div className="flex min-h-8 items-center justify-center gap-2 bg-[#ff3038] px-3 text-center text-[10px] font-medium tracking-wide">
        <Icon name="bolt" className="h-3 w-3" /> YOUR NEXT ADVENTURE, FOR LESS.{' '}
        <span className="hidden sm:inline">Explore demo deals on your favorite games.</span>
        <a href="#gallery" className="ml-2 underline underline-offset-2">
          Shop offers →
        </a>
      </div>
      <header className="relative z-30 border-b border-white/8 bg-[#0d0e14]">
        <div className="mx-auto flex h-21 max-w-[1440px] items-center justify-between gap-8 px-5 lg:px-14">
          <Link href="/" className="flex shrink-0 items-center gap-2.5">
            <div className="flex h-10 w-10 -skew-x-12 items-center justify-center rounded bg-[#ff3038] text-2xl font-black italic">
              A
            </div>
            <div className="font-heading text-[15px] font-bold leading-tight tracking-wide">
              ADNAN SAME
              <span className="block text-[10px] font-medium tracking-[.37em] text-zinc-500">
                SHOP
              </span>
            </div>
          </Link>
          <div className="hidden max-w-[430px] flex-1 items-center gap-3 rounded-lg border border-white/8 bg-[#191a22] px-4 py-3 lg:flex">
            <Icon name="search" className="h-4 w-4 text-zinc-500" />
            <input
              aria-label="Search games"
              placeholder="Search your next adventure..."
              value={query}
              onChange={(e) => {
                Q(e.target.value)
                document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' })
              }}
              className="w-full bg-transparent text-xs outline-none"
            />
            <kbd className="rounded border border-white/10 px-1 text-[10px] text-zinc-600">/</kbd>
          </div>
          <div className="flex items-center gap-5">
            <button aria-label="Search" className="lg:hidden" onClick={() => P('search')}>
              <Icon name="search" />
            </button>
            <button aria-label="Wishlist" onClick={() => P('wishlist')} className="relative">
              <Icon name="heart" />
              {wish.length > 0 && (
                <span className="absolute -right-2 -top-2 rounded-full bg-red-500 px-1 text-[9px]">
                  {wish.length}
                </span>
              )}
            </button>
            <button aria-label="Cart" onClick={() => P('cart')} className="relative">
              <Icon name="cart" />
              <span className="absolute -right-2 -top-2 rounded-full bg-red-500 px-1 text-[9px]">
                {cart.length}
              </span>
            </button>
            <span className="hidden h-7 border-r border-white/10 sm:block" />
            <button
              className="hidden items-center gap-2 text-xs sm:flex"
              onClick={() => P('account')}
            >
              <Icon name="user" />
              Login / Register
            </button>
            <button aria-label="Menu" className="md:hidden" onClick={() => M(!menu)}>
              <Icon name="menu" />
            </button>
          </div>
        </div>
        <nav
          className={`${menu ? 'flex' : 'hidden'} mx-auto max-w-[1440px] flex-wrap items-center gap-7 border-t border-white/5 px-5 py-4 text-[11px] font-medium text-zinc-400 md:flex lg:px-14`}
        >
          <Link className="text-[#ff424b]" href="/">
            Home
          </Link>
          {['All Games', 'PC', 'PlayStation', 'Xbox', 'Offline', 'Online'].map((x) => (
            <a
              key={x}
              href="#gallery"
              onClick={() => {
                F(x)
                M(false)
              }}
              className="transition hover:text-white"
            >
              {x}
              {['Offline', 'Online'].includes(x) ? ' Games' : ''}
            </a>
          ))}
          <a href="#gallery" onClick={() => S('Price: Low to High')} className="text-[#ff424b]">
            Special Offers <span className="ml-1 rounded bg-red-500/15 px-1 text-[8px]">HOT</span>
          </a>
          <button
            onClick={() => P('finder')}
            className="ml-auto flex items-center gap-2 text-zinc-300"
          >
            <Icon name="game" className="h-4 w-4" />
            Game Finder <span className="text-[#ff424b]">↗</span>
          </button>
        </nav>
      </header>
      {detail ? (
        <main>
          <div className="relative h-[350px] md:h-[480px]">
            <Art game={detail} banner />
            <div className="absolute inset-0 bg-gradient-to-t from-[#08090d] via-[#08090d]/25 to-transparent" />
            <div className="absolute bottom-10 left-[5%]">
              <Link href="/games" className="text-xs text-zinc-400">
                All Games / {detail.genre}
              </Link>
              <h1 className="font-heading mt-4 text-4xl font-bold md:text-6xl">{detail.title}</h1>
            </div>
          </div>
          <div className="mx-auto grid max-w-[1328px] gap-10 px-5 pb-20 md:grid-cols-[1.5fr_1fr]">
            <div>
              <h2 className="font-heading mb-5 text-2xl font-bold">Your next great story.</h2>
              <p className="text-sm leading-7 text-zinc-400">{detail.description}</p>
              <div className="my-8 grid grid-cols-2 gap-5 rounded-xl border border-white/10 bg-[#11121a] p-6">
                {[
                  ['Developer', detail.developer],
                  ['Publisher', detail.publisher],
                  ['Release date', detail.release],
                  ['Genre', detail.genre],
                ].map(([k, v]) => (
                  <div key={k}>
                    <p className="text-xs text-zinc-500">{k}</p>
                    <p className="mt-1 text-sm">{v || 'To be confirmed'}</p>
                  </div>
                ))}
              </div>
              <h3 className="mb-3 text-xl font-bold">PC system requirements</h3>
              <p className="whitespace-pre-line text-sm leading-7 text-zinc-400">
                {detail.requirements ||
                  'Consult the publisher for current requirements before purchasing.'}
              </p>
              <h3 className="mb-3 mt-8 text-xl font-bold">Access & activation</h3>
              <p className="text-sm leading-7 text-zinc-400">
                {detail.accessConditions} This is a demo listing. No account sharing or unlicensed
                offline activation is offered.
              </p>
              {detail.trailerURL && (
                <a
                  href={detail.trailerURL}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-6 inline-flex rounded-lg border border-white/20 px-5 py-3 text-sm"
                >
                  Watch official trailer ↗
                </a>
              )}
            </div>
            <aside className="h-fit rounded-2xl border border-white/10 bg-[#14151d] p-6">
              <div className="relative mx-auto mb-6 aspect-[3/4] max-w-[220px] overflow-hidden rounded-xl">
                <Art game={detail} />
              </div>
              <p className="mb-4 text-xs text-emerald-400">Demo listing · Not a live sale</p>
              <label className="text-xs text-zinc-400">
                Platform
                <select className="mt-2 mb-4 w-full rounded-lg border border-white/10 bg-[#1c1d28] p-3 text-white">
                  {detail.platforms?.map((p) => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
              </label>
              <p className="rounded-lg bg-white/5 p-3 text-sm">
                Standard Edition · Personal licensed copy
              </p>
              <p className="mt-5 text-3xl font-bold">
                {money(detail.price)}{' '}
                <s className="text-sm text-zinc-500">
                  {money(detail.originalPrice || detail.price)}
                </s>
              </p>
              <p className="mt-1 text-xs text-zinc-500">Sample price in BDT</p>
              <button
                onClick={() => add(detail)}
                className="mt-6 w-full rounded-lg bg-[#ff3038] py-4 text-sm font-bold"
              >
                Add to demo cart
              </button>
              <button
                onClick={() => toggle(detail)}
                className="mt-3 w-full rounded-lg border border-white/10 py-3 text-sm"
              >
                {wish.includes(detail.id) ? 'Remove from wishlist' : 'Save to wishlist'}
              </button>
            </aside>
          </div>
        </main>
      ) : (
        <>
          {!catalog && current && (
            <section className="relative isolate h-[570px] overflow-hidden md:h-[590px]">
              <Art game={current} banner className="hero-image object-[65%_center]" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#08090d] via-[#08090d]/75 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#08090d] via-transparent to-[#08090d]/10" />
              <div className="relative mx-auto max-w-[1440px] px-5 pt-15 md:pt-18 lg:px-14">
                <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-red-400/25 bg-red-500/10 px-3 py-1.5 text-[9px] font-semibold tracking-[.16em] text-red-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-red-500" />
                  YOUR WORLD. YOUR NEXT ADVENTURE.
                </div>
                <h1 className="font-heading max-w-[650px] text-[43px] font-bold leading-[1.07] tracking-[-.045em] sm:text-[58px] lg:text-[67px]">
                  YOUR NEXT
                  <br />
                  GAMING ADVENTURE
                  <br />
                  <span className="text-[#ff3038]">STARTS HERE.</span>
                </h1>
                <p className="mt-6 max-w-[390px] text-[12px] leading-6 text-zinc-400">
                  Discover amazing games for PC, PlayStation and Xbox at competitive prices. Built
                  for gamers. Made for Bangladesh.
                </p>
                <div className="mt-7 flex gap-3">
                  <a
                    href="#gallery"
                    className="flex items-center gap-6 rounded-lg bg-[#ff3038] px-6 py-3.5 text-xs font-semibold shadow-lg shadow-red-950/40"
                  >
                    Explore Games <Icon name="arrow" className="h-4 w-4" />
                  </a>
                  <a
                    href="#offers"
                    className="flex items-center gap-3 rounded-lg border border-white/20 bg-white/5 px-5 py-3.5 text-xs backdrop-blur"
                  >
                    Discover Offers <span>↗</span>
                  </a>
                </div>
                <div className="mt-8 flex items-center gap-4 text-[9px] text-zinc-400">
                  <span className="text-[#ffbc46]">★★★★★</span>
                  <span>For the love of the game.</span>
                  <span className="border-l border-white/20 pl-4">
                    Bangladesh's gaming destination
                  </span>
                </div>
              </div>
              <div className="absolute bottom-8 right-[5%] hidden text-right md:block">
                <p className="text-[9px] tracking-[.2em] text-zinc-400">IN THE SPOTLIGHT</p>
                <Link
                  href={`/games/${current.slug}`}
                  className="font-heading mt-2 block text-2xl font-bold"
                >
                  {current.title.toUpperCase()} <span className="text-red-500">↗</span>
                </Link>
                <p className="mt-2 text-[10px] text-zinc-400">
                  {current.genre} <span className="mx-2 text-red-500">/</span>{' '}
                  {current.platforms?.join(' · ')}
                </p>
                <div className="mt-5 flex justify-end gap-2">
                  {heroes.slice(0, 4).map((g, i) => (
                    <button
                      key={g.id}
                      aria-label={`Feature ${g.title}`}
                      onClick={() => H(i)}
                      className={`h-1 rounded-full ${i === slide ? 'w-9 bg-red-500' : 'w-4 bg-white/30'}`}
                    />
                  ))}
                </div>
              </div>
            </section>
          )}
          {!catalog && (
            <div className="mx-auto grid max-w-[1328px] grid-cols-2 gap-5 border-y border-white/8 px-5 py-6 md:grid-cols-4">
              {[
                ['bolt', 'Fast Digital Delivery', 'Less waiting. More playing.'],
                ['shield', 'Safe & Secure', 'Shop with confidence.'],
                ['headset', 'Local Gamer Support', 'We speak your game.'],
                ['game', 'Every Platform. One Shop.', 'PC, PlayStation & Xbox.'],
              ].map(([i, t, d]) => (
                <div key={t} className="flex items-center gap-3">
                  <div className="rounded-lg bg-red-500/8 p-2.5 text-[#ff424b]">
                    <Icon name={i} />
                  </div>
                  <div>
                    <p className="text-[11px] font-semibold">{t}</p>
                    <p className="mt-1 text-[9px] text-zinc-500">{d}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
          <main className="mx-auto max-w-[1440px] px-5 py-12 lg:px-14">
            <section className="mb-12">
              <div className="mb-5 flex items-end justify-between">
                <div>
                  <p className="mb-2 text-[9px] font-semibold tracking-[.2em] text-red-400">
                    CHOOSE YOUR BATTLEGROUND
                  </p>
                  <h2 className="font-heading text-2xl font-bold">One passion. Every platform.</h2>
                </div>
                <span className="hidden text-[10px] text-zinc-500 sm:block">
                  Your next favorite game is waiting.
                </span>
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                {[
                  ['PC', 'pc', 'from-[#152637]', 'Steam, Epic & more', 'text-sky-400'],
                  ['PlayStation', 'game', 'from-[#171c40]', 'Greatness awaits.', 'text-blue-400'],
                  ['Xbox', 'game', 'from-[#142e25]', 'Power your dreams.', 'text-green-400'],
                ].map(([t, i, b, d, c]) => (
                  <a
                    href="#gallery"
                    onClick={() => F(t)}
                    key={t}
                    className={`group relative flex items-center justify-between overflow-hidden rounded-xl border border-white/8 bg-gradient-to-r ${b} to-[#12131b] px-6 py-7`}
                  >
                    <div>
                      <h3 className="font-heading text-xl font-bold">
                        {t === 'PC' ? 'PC Gaming' : t}
                      </h3>
                      <p className="mt-1 text-[10px] text-zinc-500">{d}</p>
                      <span className={`mt-4 block text-[10px] ${c}`}>Explore games →</span>
                    </div>
                    <Icon
                      name={i}
                      className={`h-16 w-16 rotate-[-10deg] opacity-60 transition group-hover:rotate-0 ${c}`}
                    />
                  </a>
                ))}
              </div>
            </section>
            <section id="gallery" className="scroll-mt-6">
              <div className="flex items-end justify-between">
                <div>
                  <p className="mb-2 text-[9px] font-semibold tracking-[.2em] text-[#ff424b]">
                    HANDPICKED FOR YOUR NEXT OBSESSION
                  </p>
                  <h2 className="font-heading text-3xl font-bold">
                    {catalog ? 'Game Price Gallery' : 'Featured Games'}
                    <span className="text-[#ff3038]">.</span>
                  </h2>
                  <p className="mt-2 text-[11px] text-zinc-500">
                    Big worlds. Unforgettable stories. Your next adventure starts here.
                  </p>
                </div>
                <Link
                  href="/games"
                  className="hidden items-center gap-3 text-xs text-zinc-300 sm:flex"
                >
                  View all games <Icon name="arrow" className="h-4 w-4 text-red-400" />
                </Link>
              </div>
              <div className="my-6 flex flex-wrap items-center justify-between gap-4 border-b border-white/8 pb-4">
                <div className="flex max-w-full gap-2 overflow-x-auto">
                  {['All Games', 'PC', 'PlayStation', 'Xbox', 'Best Sellers', 'New Releases'].map(
                    (x) => (
                      <button
                        key={x}
                        onClick={() => F(x)}
                        className={`shrink-0 rounded-md border px-4 py-2 text-[10px] transition ${filter === x ? 'border-red-500/50 bg-red-500/10 text-red-400' : 'border-white/8 text-zinc-400 hover:border-white/30'}`}
                      >
                        {x}
                      </button>
                    ),
                  )}
                </div>
                <select
                  aria-label="Sort games"
                  value={sort}
                  onChange={(e) => S(e.target.value)}
                  className="rounded-lg border border-white/10 bg-[#11121a] px-3 py-2 text-[10px] text-zinc-400"
                >
                  {['Featured', 'Price: Low to High', 'Price: High to Low'].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              {query && (
                <p className="mb-4 text-sm text-zinc-400">
                  Results for “{query}”{' '}
                  <button className="ml-3 text-red-400" onClick={() => Q('')}>
                    Clear
                  </button>
                </p>
              )}
              <div className="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
                {shown.map(card)}
              </div>
              {!shown.length && (
                <div className="rounded-xl border border-white/10 p-12 text-center text-zinc-400">
                  No games match.{' '}
                  <button
                    onClick={() => {
                      F('All Games')
                      Q('')
                    }}
                    className="text-red-400"
                  >
                    Reset filters
                  </button>
                </div>
              )}
              <p className="mt-4 text-[10px] text-zinc-600">
                All prices shown are demo prices. Availability and activation are confirmed before
                any real purchase.
              </p>
            </section>
            <section
              id="offers"
              className="relative mt-14 overflow-hidden rounded-2xl border border-red-500/20 bg-gradient-to-r from-[#36131e] via-[#1f1424] to-[#14121e] p-7 md:p-10"
            >
              <span className="absolute -right-4 -top-10 font-heading text-[180px] font-bold text-white/[.025]">
                LEVEL UP
              </span>
              <div className="relative flex flex-col justify-between gap-6 md:flex-row md:items-center">
                <div>
                  <p className="text-[9px] tracking-[.2em] text-red-400">
                    BIG GAMES. SMALLER PRICES.
                  </p>
                  <h2 className="font-heading mt-3 text-3xl font-bold">
                    Your wishlist. Now within reach.
                  </h2>
                  <p className="mt-3 text-xs text-zinc-400">
                    Discover a new world without breaking your budget.
                  </p>
                </div>
                <a
                  href="#gallery"
                  onClick={() => S('Price: Low to High')}
                  className="flex w-fit items-center gap-8 rounded-lg bg-[#ff3038] px-6 py-4 text-xs font-bold"
                >
                  Explore the deals <Icon name="arrow" />
                </a>
              </div>
            </section>
            <section className="mt-14 grid gap-8 md:grid-cols-2">
              <div className="rounded-xl border border-white/10 bg-[#11121a] p-7">
                <p className="text-[10px] tracking-widest text-purple-400">
                  FIND YOUR NEXT FAVORITE
                </p>
                <h2 className="font-heading mt-3 text-2xl font-bold">
                  Less searching. More playing.
                </h2>
                <p className="mt-3 text-xs leading-6 text-zinc-500">
                  A massive open world or a quick match? Let us find your next game.
                </p>
                <button
                  onClick={() => P('finder')}
                  className="mt-5 flex items-center gap-3 text-xs text-purple-300"
                >
                  Launch Game Finder <Icon name="arrow" />
                </button>
              </div>
              <div className="rounded-xl border border-white/10 bg-[#11121a] p-7">
                <p className="text-[10px] tracking-widest text-sky-400">KNOW BEFORE YOU PLAY</p>
                <h2 className="font-heading mt-3 text-2xl font-bold">Is your rig ready?</h2>
                <p className="mt-3 text-xs leading-6 text-zinc-500">
                  Explore PC system requirements and make an informed choice.
                </p>
                <button
                  onClick={() => P('compatibility')}
                  className="mt-5 flex items-center gap-3 text-xs text-sky-300"
                >
                  PC Compatibility Guide <Icon name="arrow" />
                </button>
              </div>
            </section>
          </main>
        </>
      )}
      <footer className="border-t border-white/8 bg-[#0d0e14] px-5 py-12 lg:px-14">
        <div className="mx-auto grid max-w-[1328px] gap-10 md:grid-cols-[2fr_1fr_1fr_1.5fr]">
          <div>
            <p className="font-heading text-lg font-bold">
              ADNAN SAME <span className="text-red-500">SHOP.</span>
            </p>
            <p className="mt-2 text-[9px] tracking-[.16em] text-zinc-400">
              PLAY MORE. EXPERIENCE MORE.
            </p>
            <p className="mt-5 max-w-[260px] text-[11px] leading-6 text-zinc-500">
              A new home for Bangladeshi gamers. Great games, every platform, endless possibilities.
            </p>
          </div>
          <div>
            <h3 className="mb-4 text-xs font-bold">Explore</h3>
            {['PC', 'PlayStation', 'Xbox', 'All Games'].map((x) => (
              <a
                key={x}
                href="/#gallery"
                onClick={() => F(x)}
                className="mb-3 block text-[11px] text-zinc-500"
              >
                {x}
              </a>
            ))}
          </div>
          <div>
            <h3 className="mb-4 text-xs font-bold">Here to help</h3>
            {['Order Tracking', 'Support', 'Purchase conditions'].map((x) => (
              <button key={x} onClick={() => P(x)} className="mb-3 block text-[11px] text-zinc-500">
                {x}
              </button>
            ))}
            <a href="/admin" className="text-[11px] text-zinc-500">
              Shop administration ↗
            </a>
          </div>
          <div>
            <h3 className="text-xs font-bold">Stay in the game.</h3>
            <p className="my-4 text-[11px] text-zinc-500">New drops and deals. No noise.</p>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                N('Newsletter is coming soon — no email has been stored.')
              }}
              className="flex rounded-lg border border-white/10 bg-white/5 p-1"
            >
              <input
                aria-label="Newsletter email"
                type="email"
                required
                placeholder="Your email address"
                className="w-full min-w-0 bg-transparent px-3 text-[11px] outline-none"
              />
              <button aria-label="Subscribe" className="rounded-md bg-red-500 p-2">
                <Icon name="arrow" />
              </button>
            </form>
            <div className="mt-5 flex gap-3 text-[10px] font-bold text-zinc-400">
              <span>bKash</span>
              <span>Nagad</span>
              <span>VISA</span>
              <span>mastercard</span>
            </div>
            <p className="mt-2 text-[9px] text-zinc-600">Payment integration pending</p>
          </div>
        </div>
        <div className="mx-auto mt-10 flex max-w-[1328px] flex-wrap justify-between gap-4 border-t border-white/5 pt-6 text-[9px] text-zinc-600">
          <span>© 2026 Adnan Same Shop. All rights reserved.</span>
          <span>Built for Bangladesh. Powered by play.</span>
          <span>BDT ৳ · English</span>
        </div>
      </footer>
      <div className="fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-white/10 bg-[#11121a]/95 py-3 backdrop-blur md:hidden">
        {[
          ['game', 'Home'],
          ['search', 'Search'],
          ['heart', 'Wishlist'],
          ['cart', 'Cart'],
          ['user', 'Account'],
        ].map(([i, t]) => (
          <button
            key={t}
            onClick={() =>
              t === 'Home' ? window.scrollTo({ top: 0, behavior: 'smooth' }) : P(t.toLowerCase())
            }
            className="flex flex-col items-center gap-1 text-[9px] text-zinc-400"
          >
            <Icon name={i} />
            {t}
          </button>
        ))}
      </div>
      {notice && (
        <div
          role="status"
          className="fixed bottom-20 left-1/2 z-[80] w-max max-w-[90vw] -translate-x-1/2 rounded-xl border border-red-500/30 bg-[#23202b] px-6 py-4 text-xs shadow-2xl"
        >
          {notice}
          <button className="ml-5" onClick={() => N('')}>
            ×
          </button>
        </div>
      )}
      {panel && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => P('')}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-label={panel}
            className="max-h-[85vh] w-full max-w-xl overflow-y-auto rounded-2xl border border-white/10 bg-[#14151d] p-6 sm:p-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-7 flex justify-between">
              <h2 className="font-heading text-2xl font-bold capitalize">
                {panel === 'finder'
                  ? 'Find your next adventure'
                  : panel === 'cart'
                    ? 'Your cart'
                    : panel === 'wishlist'
                      ? 'Your wishlist'
                      : panel === 'account'
                        ? 'Welcome, player.'
                        : panel}
              </h2>
              <button aria-label="Close dialog" onClick={() => P('')}>
                <Icon name="close" />
              </button>
            </div>
            {panel === 'search' ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  P('')
                  document.getElementById('gallery')?.scrollIntoView()
                }}
              >
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => Q(e.target.value)}
                  placeholder="Search games..."
                  className="w-full rounded-lg border border-white/20 bg-black/20 p-4"
                />
                <button className="mt-4 rounded-lg bg-red-500 px-5 py-3 text-sm">
                  Search catalog
                </button>
              </form>
            ) : panel === 'cart' || panel === 'wishlist' ? (
              <>
                <div className="space-y-4">
                  {(panel === 'cart' ? cart : games.filter((g) => wish.includes(g.id))).map((g) => (
                    <div key={g.id} className="flex items-center gap-4 rounded-lg bg-white/5 p-3">
                      <Link
                        className="relative h-20 w-14 shrink-0 overflow-hidden rounded"
                        href={`/games/${g.slug}`}
                      >
                        <Art game={g} />
                      </Link>
                      <div className="flex-1">
                        <p className="text-sm font-bold">{g.title}</p>
                        <p className="mt-1 text-[10px] text-zinc-400">
                          PC · Standard · Licensed copy
                        </p>
                        <p className="mt-2 text-sm">
                          {money(g.price)} <span className="text-[9px] text-zinc-500">demo</span>
                        </p>
                      </div>
                      <button
                        aria-label="Remove game"
                        onClick={() =>
                          panel === 'cart' ? C(cart.filter((x) => x.id !== g.id)) : toggle(g)
                        }
                      >
                        <Icon name="close" />
                      </button>
                    </div>
                  ))}
                </div>
                {!(panel === 'cart' ? cart.length : wish.length) && (
                  <p className="py-10 text-center text-sm text-zinc-500">
                    Your next adventure is still out there. Browse games to get started.
                  </p>
                )}
                {panel === 'cart' && cart.length > 0 && (
                  <>
                    <div className="my-6 flex justify-between border-t border-white/10 pt-5">
                      <span>Demo total</span>
                      <b>{money(cart.reduce((s, g) => s + g.price, 0))}</b>
                    </div>
                    <button
                      className="w-full rounded-lg bg-red-500 p-4 text-sm font-bold"
                      onClick={() => P('checkout')}
                    >
                      Continue to demo checkout →
                    </button>
                    <p className="mt-3 text-[10px] text-zinc-500">No payment will be collected.</p>
                  </>
                )}
              </>
            ) : panel === 'finder' ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  P('')
                  document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' })
                }}
              >
                <p className="mb-5 text-sm text-zinc-400">
                  Pick your platform and budget. We’ll narrow things down.
                </p>
                <label className="text-xs">
                  Platform
                  <select
                    onChange={(e) => F(e.target.value)}
                    className="my-3 w-full rounded-lg bg-[#232430] p-3"
                  >
                    {['All Games', 'PC', 'PlayStation', 'Xbox'].map((x) => (
                      <option key={x}>{x}</option>
                    ))}
                  </select>
                </label>
                <label className="text-xs">
                  Budget preference
                  <select
                    onChange={() => S('Price: Low to High')}
                    className="my-3 w-full rounded-lg bg-[#232430] p-3"
                  >
                    <option>Best match</option>
                    <option>Budget friendly first</option>
                  </select>
                </label>
                <button className="mt-4 w-full rounded-lg bg-red-500 p-4 text-sm font-bold">
                  Find my game →
                </button>
              </form>
            ) : panel === 'compatibility' ? (
              <div className="space-y-4 text-sm leading-7 text-zinc-400">
                <p>
                  Select a game to review its publisher-provided PC requirements. Compare your CPU,
                  GPU, RAM, and available storage before purchasing.
                </p>
                {games
                  .filter((g) => g.requirements)
                  .map((g) => (
                    <Link
                      key={g.id}
                      href={`/games/${g.slug}`}
                      className="block rounded-lg border border-white/10 p-3 text-white"
                    >
                      {g.title} →
                    </Link>
                  ))}
                <p className="text-xs">
                  This guide does not scan your hardware or guarantee performance.
                </p>
              </div>
            ) : panel === 'checkout' ? (
              <DemoCheckout
                ids={cart.map((g) => g.id)}
                onSuccess={(ref) => {
                  N(`Demo order ${ref} saved. No payment collected.`)
                  C([])
                  P('account')
                }}
              />
            ) : panel === 'account' ? (
              <CustomerAccount />
            ) : (
              <div className="text-sm leading-7 text-zinc-400">
                {panel === 'Order Tracking'
                  ? 'There are no live orders in this demo. Order tracking will be available when live checkout is enabled.'
                  : panel === 'Support'
                    ? 'For purchase assistance, contact Adnan Same Shop through its verified business channels. Support contact details are not configured yet.'
                    : 'Only personal, licensed game purchases are supported. Online activation may be required even for single-player games. Offline play depends on the publisher and platform. All prices are samples; no payment is currently accepted.'}
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  )
}
