import Store from '@/components/Store'
import { getGames } from '@/lib/games'
export default async function HomePage() {
  return <Store games={await getGames()} />
}
