import Store from '@/components/Store'
import { getGames, getGame } from '@/lib/games'
import { notFound } from 'next/navigation'
export async function generateStaticParams() {
  return (await getGames()).map((g) => ({ slug: g.slug }))
}
export default async function Detail({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const game = await getGame(slug)
  if (!game) notFound()
  return <Store games={await getGames()} detail={game} />
}
