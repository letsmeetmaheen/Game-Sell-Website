import Store from '@/components/Store'
import { getGames } from '@/lib/games'
export default async function Catalog() {
  return <Store games={await getGames()} catalog />
}
